<?php
/*
--------------------------
Crear un formulario con el campo de texto nombreUbi:
<form action="../controladores/insertar2UbicacionControlador.php" method="POST">
    <input type="text" name="nombreUbi">
    <input type="submit" avlue="Añadir ubicación">
</form>

insertarNewUbicacionController.php
---------------------------------*/
?>
<p>Crear un formulario con el campo de texto nombreUbi:</p>
<form action="../controllers/insertarNewUbicacionController.php" method="POST">
    <input type="text" name="nombreUbi">
    <input type="submit" value="Añadir ubicación">
</form>


