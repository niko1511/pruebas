<?php

?>
<p>Insertar Marcas</p>
<form action="../controllers/insertarNewMarcaController.php" method="POST">
<label for="">Nombre</label><input type="text" name="Nombre"><br>
    <input type="hidden" name="id">
    <input type="submit" value="Añadir Marca">
</form>


